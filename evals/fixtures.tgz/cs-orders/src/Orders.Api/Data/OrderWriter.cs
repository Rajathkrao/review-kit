using System.Data;
using Dapper;

namespace Orders.Api.Data;

public interface IOrderWriter
{
    Task MarkCancelledAsync(Guid id, string customerId);
}

public sealed class OrderWriter(IDbConnection db) : IOrderWriter
{
    public async Task MarkCancelledAsync(Guid id, string customerId)
    {
        var sql = $"UPDATE Orders SET Status = 'Cancelled' WHERE Id = '{id}' AND CustomerId = '{customerId}'";
        await db.ExecuteAsync(sql);
    }
}
