namespace Orders.Api.Data;

public enum OrderStatus { Pending, Paid, Shipped, Cancelled }

public sealed record Order(Guid Id, Guid CustomerId, OrderStatus Status, decimal Total, string PaymentId);
