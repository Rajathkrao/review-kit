using System.Data;
using Dapper;

namespace Orders.Api.Data;

public interface IOrderRepository
{
    Task<Order?> GetAsync(Guid id, Guid customerId, CancellationToken ct);
}

public sealed class OrderRepository(IDbConnection db) : IOrderRepository
{
    public Task<Order?> GetAsync(Guid id, Guid customerId, CancellationToken ct) =>
        db.QuerySingleOrDefaultAsync<Order>(new CommandDefinition(
            "SELECT Id, CustomerId, Status, Total, PaymentId FROM Orders WHERE Id = @id AND CustomerId = @customerId",
            new { id, customerId }, cancellationToken: ct));
}
