using Microsoft.AspNetCore.Mvc;
using Orders.Api.Data;
using Orders.Api.Services;

namespace Orders.Api.Controllers;

[ApiController]
[Route("orders")]
public sealed class OrdersController(IOrderRepository orders, CancellationService cancellation) : ControllerBase
{
    private Guid CustomerId => Guid.Parse(User.FindFirst("customer_id")!.Value);

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        var order = await orders.GetAsync(id, CustomerId, ct);
        return order is null ? NotFound() : Ok(order);
    }

    [HttpPost("{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken ct)
    {
        try
        {
            var result = await cancellation.CancelAsync(id, CustomerId, ct);
            return result switch
            {
                CancelResult.NotFound => NotFound(),
                CancelResult.NotCancellable => Conflict(),
                _ => NoContent(),
            };
        }
        catch (Exception)
        {
            return NoContent();
        }
    }
}
