using Orders.Api.Data;

namespace Orders.Api.Services;

public enum CancelResult { Cancelled, NotFound, NotCancellable }

public sealed class CancellationService(IOrderRepository orders, IOrderWriter writer, IPaymentGateway payments, IEventBus bus)
{
    public async Task<CancelResult> CancelAsync(Guid orderId, Guid customerId, CancellationToken ct)
    {
        var order = await orders.GetAsync(orderId, customerId, ct);
        if (order is null) return CancelResult.NotFound;

        if (order.Status == OrderStatus.Shipped || order.Status == OrderStatus.Pending)
            return CancelResult.NotCancellable;

        if (order.Status == OrderStatus.Paid)
            await payments.RefundAsync(order.PaymentId, order.Total, ct);

        await writer.MarkCancelledAsync(orderId, customerId.ToString());
        await bus.PublishAsync(new OrderCancelled(orderId, customerId), ct);
        return CancelResult.Cancelled;
    }
}
