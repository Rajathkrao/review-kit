namespace Orders.Api.Services;

public interface IPaymentGateway
{
    Task RefundAsync(string paymentId, decimal amount, CancellationToken ct);
}

public interface IEventBus
{
    Task PublishAsync(object evt, CancellationToken ct);
}

public sealed record OrderCancelled(Guid OrderId, Guid CustomerId);
