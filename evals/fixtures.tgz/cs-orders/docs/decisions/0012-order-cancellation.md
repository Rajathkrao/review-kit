# 0012. Customers can cancel orders

Date: 2026-09-30 · Status: Accepted

## Context
Customers email support to cancel orders before they ship.

## Decision
Add `POST /orders/{id}/cancel` for the authenticated customer.

- Only orders in `Pending` or `Paid` status can be cancelled. `Shipped` and `Cancelled` orders return 409.
- A `Paid` order is refunded through `IPaymentGateway.RefundAsync` exactly once, even if the client retries the request.
- The status change and the refund must not drift: if the status update fails, no refund is issued.
- On success, publish an `OrderCancelled` event.
