# Orders API (.NET 8)

- Data access uses Dapper with parameters only (`@name`). No string-built SQL.
- Controllers stay thin: validation + call a service. Business rules live in `Services/`.
- Never catch `Exception` in controllers; the global exception middleware maps errors to ProblemDetails.
- Pass `CancellationToken` through every async call.
