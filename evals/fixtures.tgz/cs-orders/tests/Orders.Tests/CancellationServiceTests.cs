using Orders.Api.Data;
using Orders.Api.Services;
using Xunit;

namespace Orders.Tests;

public class CancellationServiceTests
{
    [Fact]
    public async Task Cancels_paid_order()
    {
        var order = new Order(Guid.NewGuid(), Guid.NewGuid(), OrderStatus.Paid, 10m, "pay_1");
        var svc = new CancellationService(new FakeRepo(order), new FakeWriter(), new FakeGateway(), new FakeBus());
        Assert.Equal(CancelResult.Cancelled, await svc.CancelAsync(order.Id, order.CustomerId, default));
    }

    private sealed class FakeRepo(Order o) : IOrderRepository { public Task<Order?> GetAsync(Guid id, Guid c, CancellationToken ct) => Task.FromResult<Order?>(o); }
    private sealed class FakeWriter : IOrderWriter { public Task MarkCancelledAsync(Guid id, string c) => Task.CompletedTask; }
    private sealed class FakeGateway : IPaymentGateway { public Task RefundAsync(string p, decimal a, CancellationToken ct) => Task.CompletedTask; }
    private sealed class FakeBus : IEventBus { public Task PublishAsync(object e, CancellationToken ct) => Task.CompletedTask; }
}
