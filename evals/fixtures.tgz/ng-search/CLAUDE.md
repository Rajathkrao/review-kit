# docs-portal (Angular 18)
- Components use ChangeDetectionStrategy.OnPush.
- Interactive elements must be keyboard accessible (WCAG 2.1 AA).
- Never bypass Angular's sanitizer for user- or API-provided text.
