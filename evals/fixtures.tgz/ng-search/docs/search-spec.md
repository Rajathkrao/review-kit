# Search box

- Typing searches as you type, after 250 ms of no typing. Results always match the latest text in the box.
- Results show the snippet with matched words emphasised.
- Selecting a result (mouse or keyboard) opens it.
- Fully keyboard accessible and announced to screen readers.
