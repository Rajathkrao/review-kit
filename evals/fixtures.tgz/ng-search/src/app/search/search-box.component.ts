import { ChangeDetectionStrategy, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { debounceTime, mergeMap } from 'rxjs';
import { Hit, SearchService } from './search.service';

@Component({
  selector: 'app-search-box',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './search-box.component.html',
})
export class SearchBoxComponent implements OnInit {
  @Output() open = new EventEmitter<Hit>();
  query = new FormControl('', { nonNullable: true });
  results: Hit[] = [];

  constructor(private search: SearchService, private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.query.valueChanges
      .pipe(debounceTime(250), mergeMap((q) => this.search.search(q)))
      .subscribe((hits) => {
        this.results.length = 0;
        this.results.push(...hits);
      });
  }

  snippet(hit: Hit): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(hit.snippet);
  }

  select(hit: Hit): void {
    this.open.emit(hit);
  }
}
