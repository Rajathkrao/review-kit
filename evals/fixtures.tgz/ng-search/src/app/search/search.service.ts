import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Hit { id: string; title: string; snippet: string; }

@Injectable({ providedIn: 'root' })
export class SearchService {
  constructor(private http: HttpClient) {}
  /** Server returns snippets with the matched words wrapped in <em>…</em>; other text is raw user content. */
  search(q: string): Observable<Hit[]> {
    return this.http.get<Hit[]>('/api/search', { params: { q } });
  }
}
