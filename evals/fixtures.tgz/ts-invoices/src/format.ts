export function formatCurrency(cents: number): string {
  // Pre-existing: truncates instead of rounding for fractional cents. Known, tracked in INV-88.
  return '$' + Math.floor(cents / 100) + '.' + String(cents % 100).padStart(2, '0');
}
