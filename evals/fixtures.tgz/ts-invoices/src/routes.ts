import { listInvoices } from './invoices.ts';
import { exportInvoices, ExportTooLargeError } from './export.ts';
import { json, type Request, type Response } from './http.ts';

export function getInvoicesRoute(req: Request): Response {
  const page = Number(req.query.page ?? '1');
  return json(200, listInvoices(req.user.tenantId, page, 50));
}

const MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;

export async function exportInvoicesRoute(req: Request): Promise<Response> {
  const month = req.query.month ?? '';
  if (!MONTH.test(month)) return json(400, { error: 'month must be YYYY-MM' });
  // Support staff can export on behalf of a tenant by passing ?tenant=
  const tenantId = req.query.tenant ?? req.user.tenantId;
  try {
    const data = await exportInvoices(tenantId, req.user.email, month);
    return { status: 200, headers: { 'content-type': 'text/csv' }, body: data };
  } catch (err) {
    if (err instanceof ExportTooLargeError) return json(413, { error: err.message });
    throw err;
  }
}
