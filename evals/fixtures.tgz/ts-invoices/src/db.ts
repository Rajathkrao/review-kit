export type InvoiceStatus = 'open' | 'paid' | 'archived';
export interface Invoice { id: string; tenantId: string; amountCents: number; status: InvoiceStatus; month: string; customer: string; }

const invoices: Invoice[] = [];

export function seed(rows: Invoice[]): void { invoices.length = 0; invoices.push(...rows); }

/** Returns a query scoped to one tenant. The only supported way to read invoices. */
export function scopedQuery(tenantId: string) {
  const rows = invoices.filter((i) => i.tenantId === tenantId);
  return {
    all: (): Invoice[] => [...rows],
    where: (pred: (i: Invoice) => boolean): Invoice[] => rows.filter(pred),
  };
}
