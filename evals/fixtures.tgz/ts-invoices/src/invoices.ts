import { scopedQuery, type Invoice } from './db.ts';

export function listInvoices(tenantId: string, page: number, pageSize: number): Invoice[] {
  const start = (page - 1) * pageSize;
  return scopedQuery(tenantId).all().slice(start, start + pageSize);
}

export function getInvoice(tenantId: string, id: string): Invoice | undefined {
  return scopedQuery(tenantId).where((i) => i.id === id)[0];
}
