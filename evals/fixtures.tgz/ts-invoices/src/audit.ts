export interface AuditRecord { type: string; tenantId: string; user: string; rows: number; at: string; }

export const auditClient = {
  sink: [] as AuditRecord[],
  failNext: 0,
  async write(rec: AuditRecord): Promise<void> {
    if (this.failNext > 0) { this.failNext--; throw new Error('audit service unavailable'); }
    this.sink.push(rec);
  },
};
