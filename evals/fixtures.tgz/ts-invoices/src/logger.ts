export const logger = {
  error(errorId: string, err: unknown): void {
    process.stderr.write(`[${errorId}] ${err instanceof Error ? err.message : String(err)}\n`);
  },
};
