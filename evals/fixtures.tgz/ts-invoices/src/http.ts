export interface Request { user: { tenantId: string; email: string }; query: Record<string, string | undefined>; }
export interface Response { status: number; headers: Record<string, string>; body: string; }
export const json = (status: number, obj: unknown): Response => ({ status, headers: { 'content-type': 'application/json' }, body: JSON.stringify(obj) });
