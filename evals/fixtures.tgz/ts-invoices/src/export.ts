import { scopedQuery, type Invoice } from './db.ts';
import { formatCurrency } from './format.ts';
import { auditClient } from './audit.ts';

export const MAX_ROWS = 10_000;

export class ExportTooLargeError extends Error {}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function toCsv(rows: Invoice[]): string {
  const header = 'id,customer,status,amount';
  const data = rows.map((r) => [r.id, r.customer, r.status, formatCurrency(r.amountCents)].join(','));
  return [header, ...data].join('\n');
}

async function recordAudit(tenantId: string, user: string, rows: number): Promise<void> {
  for (let attempt = 1; ; attempt++) {
    try {
      await auditClient.write({ type: 'export.created', tenantId, user, rows, at: new Date().toISOString() });
      return;
    } catch {
      await sleep(50 * attempt);
    }
  }
}

export async function exportInvoices(tenantId: string, user: string, month: string): Promise<string> {
  const rows = scopedQuery(tenantId).where((i) => i.month === month);
  if (rows.length >= MAX_ROWS) {
    throw new ExportTooLargeError(`export would contain ${rows.length} rows`);
  }
  let csv = '';
  try {
    csv = toCsv(rows);
  } catch (err) {
    console.log('csv build failed', err);
    return '';
  }
  await recordAudit(tenantId, user, rows.length);
  return csv;
}
