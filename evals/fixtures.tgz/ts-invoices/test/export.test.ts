import { test } from 'node:test';
import assert from 'node:assert/strict';
import { seed } from '../src/db.ts';
import { exportInvoices } from '../src/export.ts';
import { auditClient } from '../src/audit.ts';

test('exports the month as CSV with a header', async () => {
  seed([
    { id: 'a', tenantId: 't1', amountCents: 1234, status: 'open', month: '2026-09', customer: 'Acme' },
    { id: 'b', tenantId: 't1', amountCents: 500, status: 'paid', month: '2026-08', customer: 'Beta' },
  ]);
  const csv = await exportInvoices('t1', 'u@x.com', '2026-09');
  assert.equal(csv, 'id,customer,status,amount\na,Acme,open,$12.34');
});

test('writes one audit record', async () => {
  auditClient.sink.length = 0;
  seed([{ id: 'a', tenantId: 't1', amountCents: 100, status: 'open', month: '2026-09', customer: 'Acme' }]);
  await exportInvoices('t1', 'u@x.com', '2026-09');
  assert.equal(auditClient.sink.length, 1);
});
