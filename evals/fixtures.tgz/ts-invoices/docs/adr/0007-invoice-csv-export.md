# ADR-0007: Invoice CSV export

## Status
Accepted

## Context
Finance users currently copy rows from the invoice list to build monthly reports. Support gets ~40 tickets a month asking for exports.

## Decision
Add `GET /invoices/export?month=YYYY-MM` that returns a CSV of the caller's invoices for that month.

1. Only invoices of the caller's own tenant, taken from the authenticated principal.
2. Archived invoices are excluded from the export.
3. Up to 10,000 rows are allowed. A request that would produce more than 10,000 rows is rejected with HTTP 413 and no partial file.
4. Each successful export writes one audit record (`export.created`) with tenant, user and row count.
5. Columns, in order: id, customer, status, amount (formatted with `formatCurrency`).
6. If the export cannot be produced, the client gets an error response, never an empty or partial file.

## Consequences
- The CSV is built synchronously in the request. With the 10,000-row cap this takes <200 ms; we accept this instead of a background job (revisit if the cap is raised).
- Audit writes go to the audit service, which is occasionally unavailable for a few seconds during deploys.
