# invoices-service

- All invoice reads go through `scopedQuery(tenantId)` in `src/db.ts`. Never filter by tenant manually.
- The tenant always comes from the authenticated principal (`req.user.tenantId`), never from request input.
- Log failures with `logger.error(errorId, err)` from `src/logger.ts`. Do not use `console.log` in `src/`.
- Run tests with `npm test`.
