# Monthly renewals

Every active subscription is charged once per billing period, on its `nextBillingAt` date, and
then moves to the same day next month. A customer must never be charged twice for one period.
If a charge is declined the subscription becomes `past_due`. Every successful charge has an invoice.
