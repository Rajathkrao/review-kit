export interface Subscription { id: string; customerId: string; priceCents: number; status: 'active' | 'past_due' | 'cancelled'; nextBillingAt: Date; createdAt: Date; }
export interface Invoice { id: string; subscriptionId: string; amountCents: number; chargeId: string; }

export const db = {
  subscriptions: [] as Subscription[],
  invoices: [] as Invoice[],
  failInvoiceInsert: false,
};

export const subscriptionRepo = {
  /** Page of active subscriptions ordered by createdAt, after the given cursor. */
  async page(after: Date | null, limit: number): Promise<Subscription[]> {
    return db.subscriptions
      .filter((s) => s.status === 'active' && (after === null || s.createdAt > after))
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
      .slice(0, limit);
  },
  async update(id: string, patch: Partial<Subscription>): Promise<void> {
    const s = db.subscriptions.find((x) => x.id === id);
    if (s) Object.assign(s, patch);
  },
};

export const invoiceRepo = {
  async insert(inv: Invoice): Promise<void> {
    if (db.failInvoiceInsert) throw new Error('invoice table unavailable');
    db.invoices.push(inv);
  },
};
