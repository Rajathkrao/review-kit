import { subscriptionRepo, invoiceRepo, type Subscription } from './db.ts';
import { gateway } from './gateway.ts';

const PAGE_SIZE = 100;
const MAX_ATTEMPTS = 3;

export function addOneMonth(d: Date): Date {
  const next = new Date(d);
  next.setUTCMonth(next.getUTCMonth() + 1);
  return next;
}

async function chargeWithRetry(sub: Subscription) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      return await gateway.charge(sub.customerId, sub.priceCents);
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError;
}

async function renew(sub: Subscription): Promise<'renewed' | 'past_due'> {
  try {
    const { chargeId } = await chargeWithRetry(sub);
    await invoiceRepo.insert({ id: `inv_${sub.id}_${sub.nextBillingAt.toISOString()}`, subscriptionId: sub.id, amountCents: sub.priceCents, chargeId });
    await subscriptionRepo.update(sub.id, { nextBillingAt: addOneMonth(sub.nextBillingAt) });
    return 'renewed';
  } catch {
    await subscriptionRepo.update(sub.id, { status: 'past_due' });
    return 'past_due';
  }
}

/** Charges every subscription that is due. Called by cron every minute. */
export async function runRenewals(now: Date): Promise<{ renewed: number; pastDue: number }> {
  let renewed = 0, pastDue = 0;
  let cursor: Date | null = null;
  for (;;) {
    const page = await subscriptionRepo.page(cursor, PAGE_SIZE);
    if (page.length === 0) break;
    for (const sub of page) {
      if (sub.nextBillingAt <= now) {
        (await renew(sub)) === 'renewed' ? renewed++ : pastDue++;
      }
    }
    cursor = page[page.length - 1].createdAt;
  }
  return { renewed, pastDue };
}
