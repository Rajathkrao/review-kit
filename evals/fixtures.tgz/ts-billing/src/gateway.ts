export interface ChargeResult { chargeId: string; }

/** Payment gateway client. charge() may time out after the charge has gone through. */
export const gateway = {
  calls: [] as { customerId: string; amountCents: number; idempotencyKey?: string }[],
  timeoutsAfterSuccess: 0,
  async charge(customerId: string, amountCents: number, idempotencyKey?: string): Promise<ChargeResult> {
    this.calls.push({ customerId, amountCents, idempotencyKey });
    if (this.timeoutsAfterSuccess > 0) { this.timeoutsAfterSuccess--; throw new Error('ETIMEDOUT'); }
    return { chargeId: `ch_${this.calls.length}` };
  },
};
