// Pre-existing helper, untouched by the change.
export const label = (s: { id: string }) => 'sub ' + s.id;
