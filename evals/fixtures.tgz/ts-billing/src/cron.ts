import { runRenewals } from './renewals.ts';
// Scheduled every minute on each of the 3 worker instances.
export const renewalCron = { schedule: '* * * * *', run: () => runRenewals(new Date()) };
