import { test } from 'node:test';
import assert from 'node:assert/strict';
import { db } from '../src/db.ts';
import { gateway } from '../src/gateway.ts';
import { runRenewals, addOneMonth } from '../src/renewals.ts';

const sub = (id: string, due: string) => ({ id, customerId: `c_${id}`, priceCents: 1500, status: 'active' as const,
  nextBillingAt: new Date(due), createdAt: new Date(`2026-01-0${id.length}T00:00:00Z`) });

test('charges due subscriptions and moves them one month', async () => {
  db.subscriptions = [sub('a', '2026-10-15T00:00:00Z'), sub('bb', '2026-11-20T00:00:00Z')];
  db.invoices = [];
  const r = await runRenewals(new Date('2026-10-29T00:00:00Z'));
  assert.deepEqual(r, { renewed: 1, pastDue: 0 });
  assert.equal(db.subscriptions[0].nextBillingAt.toISOString(), '2026-11-15T00:00:00.000Z');
  assert.equal(db.invoices.length, 1);
});

test('addOneMonth moves to the same day next month', () => {
  assert.equal(addOneMonth(new Date('2026-03-10T00:00:00Z')).toISOString(), '2026-04-10T00:00:00.000Z');
});
