# billing-service
- The renewal job runs every minute from cron, on 3 worker instances behind the same database.
- Money is integer cents everywhere.
- Run tests with `npm test`.
